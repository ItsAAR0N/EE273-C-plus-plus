#ifndef GREETINGS_HPP
#define GREETINGS_HPP


void hello();
int new_func(int a, int b); // function not used yet but defined ready to go


#endif /* GREETINGS_HPP */
