
#include "greetings.hpp"
#include "NewHeader.hpp"
#include <string>
#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	int my_variable = 100;
	hello();
	int i = my_function(my_variable);
	return 0;
}