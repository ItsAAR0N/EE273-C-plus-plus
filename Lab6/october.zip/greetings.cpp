#include "greetings.hpp"
#include "NewHeader.hpp"
#include <iostream>
using namespace std;

void hello()
{
	cout << "Hello" << endl;
}
int my_function(int n)
{
	int i = 0;
	i = n*n;
	return i;
}
int new_function(int n, int m)
{
	int i = 0;
	i = n*m;
	return i;
}