#ifndef HARLE_H
#define HARLE_H

#include <string>
using namespace std;

/**
* @additional header to show example
*
* @nothing in it yet
*/

int my_function(int);

#endif /* HARLE_H */
